###################
NAME:	Oren Cohen
ID:	305164295
USER:	cohenorx
###################

for running this code (experiment.py), you should run it with 2 parameters: neg_examples pos_examples

i.e, ./experiment.py neg_examples pos_examples 

explanation:

main func - it will take the neg_examples and pos_examples  (from the same directory) if exists,
if not exist: the program creates new (random) examples (so put the gen_examples.py it the folder!),
and then creates the train set and test set.
